<?php
//000000000000
 exit();?>
think_serialize:a:19:{s:8:"app_init";a:2:{i:0;s:26:"app\common\behavior\Config";i:1;s:28:"app\common\behavior\InitHook";}s:9:"app_begin";a:0:{}s:11:"module_init";a:0:{}s:12:"action_begin";a:0:{}s:11:"view_filter";a:0:{}s:9:"log_write";a:0:{}s:7:"app_end";a:0:{}s:10:"pageHeader";a:0:{}s:10:"pageFooter";a:0:{}s:6:"smsGet";a:0:{}s:7:"smsSend";a:0:{}s:9:"smsNotice";a:0:{}s:8:"smsCheck";a:0:{}s:8:"smsFlush";a:0:{}s:6:"emsGet";a:0:{}s:7:"emsSend";a:0:{}s:9:"emsNotice";a:0:{}s:8:"emsCheck";a:0:{}s:8:"emsFlush";a:0:{}}