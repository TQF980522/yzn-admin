<?php
//000000000060
 exit();?>
think_serialize:a:2:{i:0;a:12:{s:2:"id";i:30;s:5:"title";s:12:"附件上传";s:4:"icon";s:0:"";s:8:"parentid";i:23;s:3:"app";s:10:"attachment";s:10:"controller";s:11:"attachments";s:6:"action";s:6:"upload";s:9:"parameter";s:0:"";s:6:"status";i:1;s:3:"tip";s:0:"";s:6:"is_dev";i:0;s:9:"listorder";i:0;}i:1;a:12:{s:2:"id";i:31;s:5:"title";s:12:"附件删除";s:4:"icon";s:0:"";s:8:"parentid";i:23;s:3:"app";s:10:"attachment";s:10:"controller";s:11:"attachments";s:6:"action";s:6:"delete";s:9:"parameter";s:0:"";s:6:"status";i:1;s:3:"tip";s:0:"";s:6:"is_dev";i:0;s:9:"listorder";i:0;}}