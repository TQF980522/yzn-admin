<?php
//000000000060
 exit();?>
think_serialize:a:1:{i:0;a:12:{s:2:"id";i:44;s:5:"title";s:12:"模块管理";s:4:"icon";s:17:"icon-mokuaishezhi";s:8:"parentid";i:43;s:3:"app";s:5:"admin";s:10:"controller";s:6:"module";s:6:"action";s:5:"index";s:9:"parameter";s:0:"";s:6:"status";i:1;s:3:"tip";s:0:"";s:6:"is_dev";i:0;s:9:"listorder";i:0;}}