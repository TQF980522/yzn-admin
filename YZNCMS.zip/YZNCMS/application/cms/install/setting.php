<?php

/**
 * 内容管理系统，默认配置
 */
return array(
    'web_site_status' => '1',
    'web_site_recycle' => '0',
    'site_name' => '御宅男工作室',
    'site_title' => '御宅男工作室',
    'site_keyword' => '御宅男CMS,CMS,YZNCMS,内容管理系统,CMS系统',
    'site_description' => 'Yzncms(又名御宅男CMS)是基于最新TP5.1框架的CMS内容管理系统。是一款完全免费开源的项目，他将是您轻松建站的首选利器。框架易于功能扩展，代码维护，方便二次开发，帮助开发者简单高效降低二次开发成本，满足专注业务深度开发的需求。',
    'site_cache_time' => '3600',
);
