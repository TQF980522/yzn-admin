<?php

/**
 * 会员系统，默认配置
 */
return array(
    'allowregister' => '1',
    'registerverify' => '0',
    'openverification' => '1',
    'defualtpoint' => '0',
    'defualtamount' => '0',
);
